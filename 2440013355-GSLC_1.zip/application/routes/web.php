<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    //  Ganti jika ingin mengubah role menjadi admin
    $data['isAdmin'] = true;

    $data['projects'] = [
        [
            'name' => 'Tugas Merdeka',
            'difficulty' => 'Hard',
            'member' => '12',
            'date' => '10 November 2022'
        ],
        [
            'name' => 'GSLC Web Programming',
            'difficulty' => 'Easy',
            'member' => '2',
            'date' => '12 November 2022'
        ],
        [
            'name' => 'Lab Web Programming',
            'difficulty' => 'Medium',
            'member' => '14',
            'date' => '13 November 2022'
        ],
    ];



    return view('dashboard', compact('data'));
});
