<?php $__env->startSection('content'); ?>
    <div class="flex flex-col w-0 flex-1 overflow-hidden">
        <main class="flex-1 relative z-0 overflow-y-auto focus:outline-none">
            <div class="hidden  sm:block">
                <div class="align-middle inline-block min-w-full border-b border-gray-200">
                    <table class="min-w-full">
                        <thead>
                            <tr class="border-t border-gray-200">
                                <th
                                    class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <span class="lg:pl-2">Project</span>
                                </th>
                                <th
                                    class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Members
                                </th>
                                <th
                                    class="hidden md:table-cell px-6 py-3 border-b border-gray-200 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Last updated
                                </th>
                                <th
                                    class="pr-6 py-3 border-b border-gray-200 bg-gray-50 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php $__currentLoopData = $data['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td
                                        class="px-6 py-3 max-w-0 w-full whitespace-nowrap text-sm font-medium text-gray-900">
                                        <div class="flex items-center space-x-3 lg:pl-2">
                                            <div class="flex-shrink-0 w-2.5 h-2.5 rounded-full bg-pink-600"
                                                aria-hidden="true">
                                            </div>
                                            <a href="#" class="truncate hover:text-gray-600">
                                                <span>
                                                    <?php echo e($project['name']); ?>

                                                    <span
                                                        class="text-gray-500 font-normal">(<?php echo e($project['difficulty']); ?>)</span>
                                                </span>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="px-6 py-3 text-sm text-gray-500 font-medium">
                                        <div class="flex items-center space-x-2">
                                            <div class="flex flex-shrink-0 -space-x-1">
                                                <?php for($i = 0; $i < $project['member']; $i++): ?>
                                                    <?php if($i <= 3): ?>
                                                        <img class="max-w-none h-6 w-6 rounded-full ring-2 ring-white"
                                                            src="https://picsum.photos/200/300" alt="Dries Vincent">
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </div>

                                            <span
                                                class="flex-shrink-0 text-xs leading-5 font-medium">+<?php echo e($project['member']); ?></span>
                                        </div>
                                    </td>
                                    <td
                                        class="hidden md:table-cell px-6 py-3 whitespace-nowrap text-sm text-gray-500 text-right">
                                        <?php echo e($project['date']); ?>

                                    </td>
                                    <td
                                        class="hidden md:table-cell px-6 py-3 whitespace-nowrap text-sm text-gray-500 text-right">
                                        <?php if($data['isAdmin']): ?>
                                            <?php echo $__env->make('button', ['title' => 'Delete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\github\gslc-webprog\application\resources\views/dashboard.blade.php ENDPATH**/ ?>