Cara menggunakan applikasi :
1. npm run dev
2. php artisan serve

-> Pergi ke web server yang disediakan (default localhost:8000)